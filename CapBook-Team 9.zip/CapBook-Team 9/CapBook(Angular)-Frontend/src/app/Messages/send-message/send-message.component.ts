import { Component, OnInit } from '@angular/core';
import { Profile } from 'src/app/profile';
import { ActivatedRoute, Router } from '@angular/router';
import { CapBookService } from 'src/app/services/cap-book.service';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-send-message',
  templateUrl: './send-message.component.html',
  styleUrls: ['./send-message.component.css']
})
export class SendMessageComponent implements OnInit {
profile:Profile;
friend:Profile;
errorMessage:string;
message:string;
  constructor(private route:ActivatedRoute,private router:Router,private capBookService:CapBookService) { }

  ngOnInit() {
    this.profile = JSON.parse(sessionStorage.getItem('profile'));
    console.log(this.profile);
    this.friend = JSON.parse(sessionStorage.getItem('friend'));
    console.log(this.friend);
  }
  onSendMessageClicked(message: string):void{
    console.log("On send message clicked");
  }
  messageForm=new FormGroup({
    message: new FormControl('')
  })
  onSubmit(){
    console.log('in submit of edit profile');
    this.capBookService.sendMessage(this.messageForm.get('message').value,this.friend.emailId).subscribe(
      message=>{
        this.message=message;
        alert("Message sent successfully");
        window.location.reload();
      },
      errorMessage=>{
        
        this.errorMessage=errorMessage;
        console.log(errorMessage);
        if(errorMessage=="Backend returned code 200")
        alert("Message sent successfully");
        else
        alert("Error");
        window.location.reload();
      })
  }
}