export interface Message {
    messageId:number,
	senderEmailId:string,
	receiverEmailId:string,
	message:string
}
