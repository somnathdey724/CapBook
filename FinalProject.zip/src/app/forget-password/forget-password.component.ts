import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';
import { Router } from '@angular/router';
import { Profile } from '../profile';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {
  forgetPasswordForm= new FormGroup({
    emailId: new FormControl(''),
    securityQuestion: new FormControl(''),
    securityAnswer: new FormControl('')
  });
  
  constructor(private capbookService:CapBookService,private router:Router) { }
  title = 'CapBook';
  profile:Profile;

  ngOnInit() {
   
  }
  errorMessage:string;
  message:string;

  onSubmit() {
    console.log('in submit of edit profile');
    this.capbookService.forgotPassword(this.forgetPasswordForm).subscribe(
      profile=>{
        this.profile=profile;
        alert(profile.password);
        this.router.navigate(['/capBookHome']);
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
        console.log('in error of edit profile');
        alert("Please enter valid credentials!!");
      })
  }
}   
 

