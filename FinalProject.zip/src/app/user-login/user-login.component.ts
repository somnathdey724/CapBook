import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Profile } from '../profile';


@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  profile:Profile;
  errorMessage:string;
  message:string;
  loginForm: FormGroup;
  constructor(private formBuilder: FormBuilder,private capbookService:CapBookService,private route:ActivatedRoute,private router:Router ) { }

  onSubmit():void{
    console.log("In OnSubmit")
    this.capbookService.userLogin(this.loginForm).subscribe(
      profile=>{
        this.profile=profile;
        console.log('in success of userlogin');
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
        console.log('in error of userlogin ');
        if(errorMessage=="Backend returned code 200, body was: Http failure during parsing for http://localhost:8085/loginUser"){
        console.log('in if of error+ '); 
        
        this.router.navigate(['userProfile']);
        }
        else{
          alert('Invalid ID or password');
        }
      }
      )
      
  }
  
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      emailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    })
  }

}
