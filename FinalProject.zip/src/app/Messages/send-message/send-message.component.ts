import { Component, OnInit } from '@angular/core';
import { Profile } from 'src/app/profile';

@Component({
  selector: 'app-send-message',
  templateUrl: './send-message.component.html',
  styleUrls: ['./send-message.component.css']
})
export class SendMessageComponent implements OnInit {
profile:Profile;
/* friend:Profile; */
  constructor() { }

  ngOnInit() {
    this.profile = JSON.parse(sessionStorage.getItem('profile'));/* 
    this.friend = JSON.parse(sessionStorage.getItem('friend')); */
  }

}
