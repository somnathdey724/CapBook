import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CapBookService } from 'src/app/services/cap-book.service';
import { Router } from '@angular/router';
import { Friend } from 'src/app/friend';

@Component({
  selector: 'app-user-plus',
  templateUrl: './user-plus.component.html',
  styleUrls: ['./user-plus.component.css']
})
export class UserPlusComponent implements OnInit {
  friend: Friend;
  errorMessage:string;
  constructor(private capbookService:CapBookService,private router:Router) { }
  @Input() emailId: string;

  @Output() addFriendClicked: EventEmitter<string> = new EventEmitter<string>();
  
  onClick(): void{
    this.capbookService.addFriend(this.emailId).subscribe(
      friend=>{
        this.friend=friend;
        alert("Friend Request placed successfully...!!!");
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
        if(errorMessage=="Backend returned code 417")
        alert("Friend Request already placed...!!!");
      }
    );
  }
  ngOnInit() {
  }

}
