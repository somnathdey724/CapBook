import { Component, OnInit } from '@angular/core';
import { CapBookService } from '../services/cap-book.service';
import { Router } from '@angular/router';
import { Profile } from '../profile';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-find-friends',
  templateUrl: './find-friends.component.html',
  styleUrls: ['./find-friends.component.css']
})
export class FindFriendsComponent implements OnInit {

  constructor(private capbookService:CapBookService,private router:Router) { }
  title = 'CapBook';
  profiles:Profile[];
  profile:Profile;

  ngOnInit() {
    this.profile = JSON.parse(sessionStorage.getItem('profile'));
  }
  errorMessage:string;
  message:string;
  findFriendsForm= new FormGroup({
    name: new FormControl('')
  });
  onSubmit() {
    console.log('in submit of edit profile');
    this.capbookService.findFriends(this.findFriendsForm.get('name').value).subscribe(
      profiles=>{
        this.profiles=profiles;
        this.profile = JSON.parse(sessionStorage.getItem('profile'));
        console.log('friend list');
        this.router.navigate(['/findFriends']);
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
        console.log('error');
        console.log('in error of edit profile');
        alert("No friends found");
      })
  }

}
