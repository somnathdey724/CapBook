import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapBookService } from 'src/app/services/cap-book.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Profile } from 'src/app/profile';

@Component({
  template: ` 
  <div> 
    <h2>Data from EditPhotoComponent: {{ profile }} </h2> 
    <input [(ngModel)] = profile /> 
    <br><br> 
    <a [routerLink]="['/userProfile']">Go to UserLogin</a> 
  </div> 
  `,
  selector: 'app-edit-photo',
  templateUrl: './edit-photo.component.html',
  styleUrls: ['./edit-photo.component.css']
})
export class EditPhotoComponent implements OnInit {
  fileToUpload: File = null;
  profile:Profile;
  constructor(private route:ActivatedRoute,private router:Router,private capBookService:CapBookService) { }
  editPhotoForm = new FormGroup({
    
    Image: new FormControl('')
  })
  profilePic:File;
  errorMessage:string;
  ngOnInit() {
    this.profile = JSON.parse(sessionStorage.getItem('profile'));
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
    this.uploadFileToActivity();
}

 uploadFileToActivity() {
  console.log("in upload");
  this.capBookService.postFile(this.fileToUpload).subscribe(
   
    data => {
    console.log("success");
    window.location.reload();
    }, 
     error => {
      console.log(error);
      window.location.reload();
      this.router.navigate(['/userProfile']);
    });
}
}
