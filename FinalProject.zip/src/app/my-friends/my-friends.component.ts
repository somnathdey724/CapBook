import { Component, OnInit } from '@angular/core';
import { CapBookService } from '../services/cap-book.service';
import { Router } from '@angular/router';
import { Profile } from '../profile';

@Component({
  selector: 'app-my-friends',
  templateUrl: './my-friends.component.html',
  styleUrls: ['./my-friends.component.css']
})
export class MyFriendsComponent implements OnInit {

  constructor(private capbookService:CapBookService,private router:Router) { }
  title = 'CapBook';
  profiles:Profile[];
  profile:Profile;
  errorMessage:string;
  message:string;
  ngOnInit() {
    this.profile = JSON.parse(sessionStorage.getItem('profile'));  
    console.log('in submit of edit profile');
    this.capbookService.myFriends().subscribe(
      profiles=>{
        this.profiles=profiles;
        this.profile = JSON.parse(sessionStorage.getItem('profile'));
        console.log('friend list');
        this.router.navigate(['/myFriends']);
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
        console.log('error');
        console.log('in error of edit profile');
        alert("No friends found");
      })
  }
}
