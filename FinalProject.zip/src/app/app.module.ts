import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule, MatToolbarModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { RouterModule } from '@angular/router';
import { CapBookService } from './services/cap-book.service';
import { UserLoginComponent } from './user-login/user-login.component';
import { HttpClientModule } from '@angular/common/http';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { CapBookHomeComponent } from './cap-book-home/cap-book-home.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { EditPhotoComponent } from './user-profile/edit-photo/edit-photo.component';
import { UserDetailsComponent } from './change-password/user-details.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { FindFriendsComponent } from './find-friends/find-friends.component';



@NgModule({
  declarations: [
    AppComponent,
    UserRegistrationComponent,
    UserLoginComponent,
    UserProfileComponent,
    CapBookHomeComponent,
    UserDetailsComponent,
    EditProfileComponent,
    EditPhotoComponent,
    ForgetPasswordComponent,
    FindFriendsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatToolbarModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      {path: 'capBookHome',component: CapBookHomeComponent},
      {path:'',redirectTo:'capBookHome',pathMatch:'full'},
      {path: 'userProfile',component: UserProfileComponent},
      {path: 'userLogin',component: UserLoginComponent},
      {path: 'editProfile',component: EditProfileComponent},
      {path: 'editPhoto',component: EditPhotoComponent},
      {path: 'forgetPassword',component: ForgetPasswordComponent},
      {path:'userDetails',component:UserDetailsComponent},
      {path:'findFriends',component:FindFriendsComponent}
      
    ])
  ],
  exports: [MatButtonModule, MatToolbarModule],
  providers: [CapBookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
