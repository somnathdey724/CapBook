import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CapBookHomeComponent } from './cap-book-home.component';

describe('CapBookHomeComponent', () => {
  let component: CapBookHomeComponent;
  let fixture: ComponentFixture<CapBookHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CapBookHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CapBookHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
