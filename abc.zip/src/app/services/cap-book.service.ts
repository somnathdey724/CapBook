import { Injectable } from '@angular/core';
import { HttpClient,HttpParams,HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { FormGroup } from '@angular/forms';
import {map,catchError} from 'rxjs/operators';
import { IfStmt } from '@angular/compiler';
import { Profile } from '../profile';


@Injectable({
  providedIn: 'root'
})
export class CapBookService {
  profile:Profile;
  constructor(private httpClient: HttpClient) { }

  public userRegistration(registrationForm:FormGroup):Observable<string>{
    let body = JSON.parse(JSON.stringify(registrationForm.value));
    return this.httpClient.post<string>("http://localhost:8085/registerUser",body).pipe(catchError(this.handleError));
 }
  
   public userLogin(loginForm:FormGroup):Observable<Profile>{
     let body=JSON.parse(JSON.stringify(loginForm.value));
     return this.httpClient.post<Profile>("http://localhost:8085/loginUser",body).pipe(catchError(this.handleError));     
  }
 
  // error Handler
  private handleError(error: any){
    if(error instanceof ErrorEvent){
      console.error(`1 An ErrorEvent occurred: `,error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was: ${error.message}`);
    }else if(error instanceof TypeError){
      console.error(`3 TypeError has occurred ${error.message}, body was: ${error.stack}`);
      return throwError(`TypeError has occurred ${error.message}, body was: ${error.stack}`);
    }
  }

  
}