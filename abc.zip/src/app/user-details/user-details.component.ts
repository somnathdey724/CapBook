import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';
import { ActivatedRoute,Router } from '@angular/router';


@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  
  submitted=false;
 
  constructor(private route:ActivatedRoute,private router:Router,private formBuilder: FormBuilder,private capbookService:CapBookService) { }
  registerForm: FormGroup;

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
          
          password: ['', [Validators.required, Validators.minLength(6)]],
          confirmPassword: ['', [Validators.required, Validators.minLength(6)]],
      });
  }
  onSubmit() {
     this.submitted = true;
    /*
    if((this.registerForm.get('password').value)!=(this.registerForm.get('confirmPassword').value)){
      console.log("In If")
      this.errorMessage="Password Does Not Match";
    }
    else{
      console.log("In Else")
    this.capbookService.userRegistration(this.registerForm).subscribe(
      message=>{
        this.message=message;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    )
    }
    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    } */

    alert(' Your Password Is Changed Sucessfuly!!');
    this.router.navigate(['userProfile']);
    
  }
}
