import { Component, OnInit } from '@angular/core';
import { CapBookService } from 'src/app/services/cap-book.service';
import { Router } from '@angular/router';
import { Message } from 'src/app/message';
import { Profile } from 'src/app/profile';

@Component({
  selector: 'app-received-messages',
  templateUrl: './received-messages.component.html',
  styleUrls: ['./received-messages.component.css']
})
export class ReceivedMessagesComponent implements OnInit {

  constructor(private capbookService:CapBookService,private router:Router) { }
  title = 'CapBook';
  messages:Message[];
  profile:Profile;
  errorMessage:string;
  ngOnInit() {
    console.log('in submit of edit profile');
    this.capbookService.receivedMessages().subscribe(
      messages=>{
        this.messages=messages;
        console.log(messages);
        this.profile = JSON.parse(sessionStorage.getItem('profile'));
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      })
  }

}
